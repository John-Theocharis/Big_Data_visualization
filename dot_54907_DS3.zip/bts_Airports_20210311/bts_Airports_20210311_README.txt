README for �Airports 2001-Present� dataset.
Federal Aviation Administration(FAA); U.S. Department of Transportation (USDOT), Bureau of Transportation Statistics (BTS)[distributor]
2021

----------------------------------------------------------------
LINKS TO DATASET
----------------------------------------------------------------

A. Dataset archive link: 
       https://doi.org/10.21949/1520795


----------------------------------------------------------------
SUMMARY OF DATASET
----------------------------------------------------------------
The Airports dataset is as of June 20, 2019 and is from the Federal Aviation Administration (FAA), and part of the U.S. Department of Transportation (USDOT)/Bureau of Transportation Statistics� (BTS�) National Transportation Atlas Database (NTAD). The Airports dataset includes all official and operational aerodromes  and is part of the U.S. Department of Transportation (USDOT)/Bureau of Transportation Statistics (BTS) National Transportation Atlas Database (NTAD). The Airports database is a geographic point database of official operational aerodromes in the United States and U.S. Territories. Attribute data is provided on the physical and operational characteristics of the aerodrome, current usage including enplanements and aircraft operations, congestion levels and usage categories. This geospatial data is derived from the FAA's National Airspace System Resource Aeronautical Data Product.


----------------------------------------------------------------
TABLE OF CONTENTS
----------------------------------------------------------------

A. General Information
B. Sharing/Access & Policies Information
C. Data and Related File Overview
D. Methodological Information
E. Data-Specific Information for: Airports 2001-Present [datasets]
F. Update Log



----------------------------------------------------------------
A. GENERAL INFORMATION
----------------------------------------------------------------

0. Title of Dataset: 
   Airports 2001-Present [dataset]


1. Description of Dataset:
The Airports dataset is as of June 20, 2019 and is from the Federal Aviation Administration (FAA), and part of the U.S. Department of Transportation (USDOT)/Bureau of Transportation Statistics� (BTS�) National Transportation Atlas Database (NTAD).The Airports dataset includes all official and operational aerodromes  and is part of the U.S. Department of Transportation (USDOT)/Bureau of Transportation Statistics (BTS) National Transportation Atlas Database (NTAD). The Airports database is a geographic point database of official operational aerodromes in the United States and U.S. Territories. Attribute data is provided on the physical and operational characteristics of the aerodrome, current usage including enplanements and aircraft operations, congestion levels and usage categories. This geospatial data is derived from the FAA's National Airspace System Resource Aeronautical Data Product.

2. Dataset archive link: 
       https://doi.org/10.21949/1520795


3. Authorship Information:
   Principal Data Creator or Data Manager Contact Information
           Institution: Federal Aviation Administration(FAA)
           Address:  800 Independence Avenue, SW, Washington D.C. 20032
           Phone:301-427-4891

   Data Distributor Contact Information
        Name: National Transportation Atlas Database (NTAD)
           Institution: U.S. Department of Transportation, Bureau of Transportation Statistics (BTS), The Office of Spatial Analysis and Visulatization (OSAV)
           Address: 1200 New Jersey Ave. SE, Washington D.C. 20590
           Email: ntad@dot.gov
	   
	   
4. Date of data collection and update interval:
   Annually


5. Geographic location of data collection: 
   United States of America


6. Information about funding sources that supported the collection of the data:
   U.S. Department of Transportation, Federal Aviation Administration(FAA)




----------------------------------------------------------------
B. SHARING/ACCESS & POLICIES INFORMATION 
----------------------------------------------------------------

0. Recommended citation for the data: 
  U.S. Army Corp of Engineers; U.S. Department of Transportation, Bureau of Transportation Statistics (BTS)[distributor]. (2020). NARN 2050-Present [datasets]. (https://doi.org/10.21949/1520795)

1. Licenses/restrictions placed on the data:
   These data are in the Public Domain.


2. Was data derived from another source?:
   No. 
   
3. This dataset and its documentation was created and shared to meet the requirements enumerated in the U.S. Department of Transportation's "Plan to Increase Public Access to the Results of Federally-Funded Federally-Funded Scientific Research" Version 1.1 << https://doi.org/10.21949/1520559 >> and guidelines suggested by the DOT Public Access website << https://doi.org/10.21949/1503647  >>, in effect and current as of December 03, 2020.
 



----------------------------------------------------------------
C. DATA & RELATED FILE OVERVIEW
----------------------------------------------------------------

1. File List for the bts_Airports_20210311.zip collection      

   A. Filename:
      airport_XXXX.zip
	Short description:
	Compressed file folders containing the geospatial data for Airports 2001-Present dataset. Listed below are the names of the compressed file folders, classified by vintage date:
	AIRPORT_2001.zip, airport_2002.zip,airport_2004.zip,airport_2005.zip,airport_2006.zip,airport_2007.zip,airport_2008.zip,airport_2009.zip,airport_2010.zip,airport_2011.zip,airport_2012.zip,airport_2013.zip,airport_2014.zip,airport_2015.zip,

   B. Filename: 
      bts_Airports_DMP_20210311.pdf      
        Short description: 
        A PDF file containing the Data Management Plan that was created for current and future management of the data and associated files. 
 
   C. Filename: 
      bts_Airports_20210311_README.txt     
        Short description: 
        The README.txt file that includes human-readable information about the data, variable definitions, contact information, and other contextual information. The file you are reading now.    

2. File List for the airport_XXXX.zip collection

   A. Filename:
       airport.shp
	Short description:
	A shapefile containing the geospatial data for Airports 2001-Present dataset. This includes associated files with extensions .prj, .dbf, .sbn, .sbx, .shx.

   B. Filename: 
       airport.txt
        Short description: 
        A text file containing key metadata and documentation information such as methodology, procedures, data dictionary, etc.  



----------------------------------------------------------------
D. METHODOLOGICAL INFORMATION
----------------------------------------------------------------

1. Description of methods used for collection/generation of data: 
   N/A

2. Instrument- or software-specific information needed to interpret the data:
   The data and documentation files can be opened with Esri ArcMap and any GIS software package. 



----------------------------------------------------------------
E. DATA-SPECIFIC INFORMATION  
----------------------------------------------------------------

1. XXXXXX data table
   Data is updated annually. Dataset Manager is contacted to verify changes to data resulting in NTAD update. The metadata is updated in the same manner. For the most recent data, please visit the NTAD catalog at https://data-usdot.opendata.arcgis.com/ 

A. Number of variables (columns):
   The data dictionary found in (.txt documentation) provides definitions for the variables
   

B. Data Dictionary/Variable List:
   Because of the large number of variables, please refer to the Data Dictionary found within the file airports.txt for names, definitions, and formats of variables.


C. Missing data codes:
   None




----------------------------------------------------------------
F. UPDATE LOG
----------------------------------------------------------------

This bts_Airports_20210311_README.txt file was originally created on 2021-03-11 by Dominic Menegus, Geographer, dominic.menegus@dot.gov

[Note changes or update to the readme.txt file, e.g.:]

2021-03-11: Original file created




